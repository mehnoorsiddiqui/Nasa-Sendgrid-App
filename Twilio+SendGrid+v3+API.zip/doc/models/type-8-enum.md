
# Type 8 Enum

The type of the field.

## Enumeration

`Type8Enum`

## Fields

| Name |
|  --- |
| `date` |
| `text` |
| `number` |

