
# V3 Asm Groups Suppressions Response

## Structure

`V3AsmGroupsSuppressionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `recipientEmails` | `string[] \| undefined` | Optional | The email addresses you added to the unsubscribe group |

## Example (as JSON)

```json
{
  "recipient_emails": null
}
```

