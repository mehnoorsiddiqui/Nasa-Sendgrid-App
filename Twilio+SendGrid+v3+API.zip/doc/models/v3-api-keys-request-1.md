
# V3 Api Keys Request 1

## Structure

`V3ApiKeysRequest1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | The new name of the API Key. |

## Example (as JSON)

```json
{
  "name": "A New Hope"
}
```

