
# Stat 2

## Structure

`Stat2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `metrics` | [`Metrics3 \| undefined`](../../doc/models/metrics-3.md) | Optional | - |

## Example (as JSON)

```json
{
  "metrics": null
}
```

