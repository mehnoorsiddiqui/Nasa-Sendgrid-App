
# Error 4

## Structure

`Error4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | A message explaining why the IP couldn't entered into warmup mode. |

## Example (as JSON)

```json
{
  "field": null,
  "message": null
}
```

