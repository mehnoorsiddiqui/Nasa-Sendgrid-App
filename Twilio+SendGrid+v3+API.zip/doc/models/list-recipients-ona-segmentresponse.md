
# List Recipients Ona Segmentresponse

## Structure

`ListRecipientsOnaSegmentresponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `recipients` | [`ContactDBRecipient[]`](../../doc/models/contact-db-recipient.md) | Required | - |

## Example (as JSON)

```json
{
  "recipients": [
    {
      "recipients": null
    },
    {
      "recipients": null
    },
    {
      "recipients": null
    }
  ]
}
```

