
# Active 1 Enum

Set the version as the active version associated with the template (0 is inactive, 1 is active). Only one version of a template can be active. The first version created for a template will automatically be set to Active.

## Enumeration

`Active1Enum`

## Fields

| Name |
|  --- |
| `enum0` |
| `enum1` |

