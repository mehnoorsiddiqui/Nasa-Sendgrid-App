
# List Recipientsresponse

## Structure

`ListRecipientsresponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `recipients` | `unknown[]` | Required | - |

## Example (as JSON)

```json
{
  "recipients": [
    {
      "key1": "val1",
      "key2": "val2"
    },
    {
      "key1": "val1",
      "key2": "val2"
    },
    {
      "key1": "val1",
      "key2": "val2"
    }
  ]
}
```

