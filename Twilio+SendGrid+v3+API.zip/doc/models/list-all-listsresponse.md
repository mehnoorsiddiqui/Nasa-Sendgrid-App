
# List All Listsresponse

## Structure

`ListAllListsresponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lists` | [`ContactDBlists[]`](../../doc/models/contact-d-blists.md) | Required | - |

## Example (as JSON)

```json
{
  "lists": {
    "id": 1,
    "name": "listname",
    "recipient_count": 0
  }
}
```

