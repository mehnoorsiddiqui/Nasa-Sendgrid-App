
# Type 7 Enum

What differs between the A/B tests

## Enumeration

`Type7Enum`

## Fields

| Name |
|  --- |
| `subject` |
| `content` |

