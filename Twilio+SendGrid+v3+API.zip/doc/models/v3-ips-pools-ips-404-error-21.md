
# V3 Ips Pools Ips 404 Error 21

## Structure

`V3IpsPoolsIps404Error21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `string \| undefined` | Optional | An error explaining why the IP address could not be removed from the IP pool. |

## Example (as JSON)

```json
{
  "error": null
}
```

