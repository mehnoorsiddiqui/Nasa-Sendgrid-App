
# Createa Listrequest

## Structure

`CreateaListrequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | - |

## Example (as JSON)

```json
{
  "name": "your list name"
}
```

