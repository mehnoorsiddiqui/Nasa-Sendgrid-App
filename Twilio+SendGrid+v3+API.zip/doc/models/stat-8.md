
# Stat 8

## Structure

`Stat8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `string \| undefined` | Optional | The type of segmentation. |
| `name` | `string \| undefined` | Optional | The name of the specific segmentation. |
| `metrics` | [`Metrics7 \| undefined`](../../doc/models/metrics-7.md) | Optional | - |

## Example (as JSON)

```json
{
  "type": null,
  "name": null,
  "metrics": null
}
```

