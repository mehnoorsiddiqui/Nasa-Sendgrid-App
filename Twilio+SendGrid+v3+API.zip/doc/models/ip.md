
# Ip

## Structure

`Ip`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ip` | `string` | Required | An IP address that you want to allow. |

## Example (as JSON)

```json
{
  "ip": "ip4"
}
```

