
# Errors 2

## Structure

`Errors2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string \| undefined` | Optional | The name of the error. |
| `message` | `string \| undefined` | Optional | A message explaining why the IP addresses could not be listed. |

## Example (as JSON)

```json
{
  "field": null,
  "message": null
}
```

