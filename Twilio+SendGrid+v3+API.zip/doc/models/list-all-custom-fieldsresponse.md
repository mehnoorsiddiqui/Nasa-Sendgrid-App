
# List All Custom Fieldsresponse

## Structure

`ListAllCustomFieldsresponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `customFields` | [`ContactDBCustomfieldschemawithID[]`](../../doc/models/contact-db-customfieldschemawith-id.md) | Required | - |

## Example (as JSON)

```json
{
  "custom_fields": [
    {
      "name": null,
      "type": null,
      "id": null
    },
    {
      "name": null,
      "type": null,
      "id": null
    },
    {
      "name": null,
      "type": null,
      "id": null
    }
  ]
}
```

