
# Country Enum

## Enumeration

`CountryEnum`

## Fields

| Name |
|  --- |
| `uS` |
| `cA` |

