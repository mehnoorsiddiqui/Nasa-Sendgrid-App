
# Status 9 Enum

The status you would like the scheduled send to have.

## Enumeration

`Status9Enum`

## Fields

| Name |
|  --- |
| `cancel` |
| `pause` |

