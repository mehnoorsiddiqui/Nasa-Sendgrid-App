
# Type 1 Enum

The type of DNS record generated.

## Enumeration

`Type1Enum`

## Fields

| Name |
|  --- |
| `cname` |
| `txt` |
| `mx` |

