
# Generations Enum

## Enumeration

`GenerationsEnum`

## Fields

| Name |
|  --- |
| `legacy` |
| `dynamic` |
| `enumLegacydynamic` |

