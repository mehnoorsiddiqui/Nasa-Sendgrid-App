
# Errors 71

## Structure

`Errors71`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | - |
| `errorIndices` | `number[] \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": null,
  "error_indices": null
}
```

