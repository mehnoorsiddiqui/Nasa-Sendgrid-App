
# V3 Contactdb Custom Fields Request

## Structure

`V3ContactdbCustomFieldsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | - |
| `type` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "name": "pet",
  "type": "text"
}
```

