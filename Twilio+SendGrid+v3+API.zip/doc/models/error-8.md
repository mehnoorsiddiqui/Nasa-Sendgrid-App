
# Error 8

## Structure

`Error8`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | A message describing why the IP whitelabel could not be validated. |

## Example (as JSON)

```json
{
  "message": "message0"
}
```

