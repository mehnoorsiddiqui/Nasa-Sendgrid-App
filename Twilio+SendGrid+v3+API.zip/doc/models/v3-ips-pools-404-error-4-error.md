
# V3 Ips Pools 404 Error 4 Error

## Structure

`V3IpsPools404Error4Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `string \| undefined` | Optional | An error explaining why the pool could not be deleted. |

## Example (as JSON)

```json
{
  "error": null
}
```

