
# Error 7

## Structure

`Error7`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | A message describing why the reverse DNS could not be validated. |

## Example (as JSON)

```json
{
  "message": "message0"
}
```

