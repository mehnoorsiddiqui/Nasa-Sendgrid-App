
# Status 8 Enum

The status of the scheduled send.

## Enumeration

`Status8Enum`

## Fields

| Name |
|  --- |
| `cancel` |
| `pause` |

