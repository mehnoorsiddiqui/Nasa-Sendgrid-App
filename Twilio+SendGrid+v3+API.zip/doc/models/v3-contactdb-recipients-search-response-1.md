
# V3 Contactdb Recipients Search Response 1

## Structure

`V3ContactdbRecipientsSearchResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `recipients` | [`Recipient1[] \| undefined`](../../doc/models/recipient-1.md) | Optional | - |
| `recipientCount` | `number \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "recipients": null,
  "recipient_count": null
}
```

