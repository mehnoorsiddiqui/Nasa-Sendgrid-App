
# Error 3

## Structure

`Error3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | The reason why the link whitelabel could not be validated. |

## Example (as JSON)

```json
{
  "message": "message0"
}
```

