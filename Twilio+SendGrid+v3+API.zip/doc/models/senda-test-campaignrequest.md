
# Senda Test Campaignrequest

## Structure

`SendaTestCampaignrequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `to` | `string` | Required | - |

## Example (as JSON)

```json
{
  "to": "to6"
}
```

