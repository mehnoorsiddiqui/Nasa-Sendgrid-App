
# V3 Alerts 400 Error 1 Error

## Structure

`V3Alerts400Error1Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "field": null,
  "message": null
}
```

