
# Self Metadata

## Structure

`SelfMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `self` | `string \| undefined` | Optional | A link to this object. |

## Example (as JSON)

```json
{
  "self": null
}
```

