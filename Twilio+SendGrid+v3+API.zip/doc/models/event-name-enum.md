
# Event Name Enum

Name of event

## Enumeration

`EventNameEnum`

## Fields

| Name |
|  --- |
| `bounced` |
| `opened` |
| `clicked` |
| `processed` |
| `dropped` |
| `delivered` |
| `deferred` |
| `spamReport` |
| `unsubscribe` |
| `groupUnsubscribe` |
| `groupResubscribe` |

