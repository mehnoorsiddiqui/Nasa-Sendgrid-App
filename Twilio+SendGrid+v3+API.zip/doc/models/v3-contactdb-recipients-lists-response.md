
# V3 Contactdb Recipients Lists Response

## Structure

`V3ContactdbRecipientsListsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `lists` | [`ContactDBlists[] \| undefined`](../../doc/models/contact-d-blists.md) | Optional | - |

## Example (as JSON)

```json
{
  "lists": null
}
```

