
# Errors 72

## Structure

`Errors72`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | - |
| `errorId` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": null,
  "error_id": null
}
```

