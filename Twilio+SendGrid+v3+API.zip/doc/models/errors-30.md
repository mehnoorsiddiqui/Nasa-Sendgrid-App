
# Errors 30

## Structure

`Errors30`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": null
}
```

