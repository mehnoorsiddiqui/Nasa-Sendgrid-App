
# Accept 1 Enum

Specifies the content type to be returned by this endpoint. You can choose to receive CSV-formatted data by passing "text/csv" in the header.

## Enumeration

`Accept1Enum`

## Fields

| Name |
|  --- |
| `enumApplicationjson` |
| `enumTextcsv` |

