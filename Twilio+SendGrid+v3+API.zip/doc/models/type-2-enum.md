
# Type 2 Enum

The type of alert you want to create. Can be either usage_limit or stats_notification.
Example: usage_limit

## Enumeration

`Type2Enum`

## Fields

| Name |
|  --- |
| `statsNotification` |
| `usageLimit` |

