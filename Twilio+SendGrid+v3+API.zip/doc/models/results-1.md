
# Results 1

## Structure

`Results1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `senderVerified` | `boolean \| undefined` | Optional | - |
| `domainVerified` | `boolean \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "sender_verified": null,
  "domain_verified": null
}
```

