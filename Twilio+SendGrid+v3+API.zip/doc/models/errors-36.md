
# Errors 36

## Structure

`Errors36`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | - |
| `field` | `string` | Required | - |

## Example (as JSON)

```json
{
  "message": "message0",
  "field": "field6"
}
```

