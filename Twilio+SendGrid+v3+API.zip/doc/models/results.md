
# Results

## Structure

`Results`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `softFailures` | `string[]` | Required | - |
| `hardFailures` | `string[]` | Required | - |

## Example (as JSON)

```json
{
  "soft_failures": [
    "soft_failures7"
  ],
  "hard_failures": [
    "hard_failures9",
    "hard_failures0",
    "hard_failures1"
  ]
}
```

