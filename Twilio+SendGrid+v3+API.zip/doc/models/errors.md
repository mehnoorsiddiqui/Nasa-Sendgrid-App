
# Errors

## Structure

`Errors`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `string \| undefined` | Optional | - |
| `field` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "error": null,
  "field": null
}
```

