
# From 1

## Structure

`From1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `string \| undefined` | Optional | The email address from which your recipient will receive emails. |
| `name` | `string \| undefined` | Optional | The name appended to the from email field. Typically your name or company name. |

## Example (as JSON)

```json
{
  "email": null,
  "name": null
}
```

