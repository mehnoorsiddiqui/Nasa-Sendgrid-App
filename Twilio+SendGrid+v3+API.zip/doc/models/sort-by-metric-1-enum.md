
# Sort by Metric 1 Enum

The metric that you want to sort by. Metrics that you can sort by are: `blocks`, `bounces`, `clicks`, `delivered`, `opens`, `requests`, `unique_clicks`, `unique_opens`, and `unsubscribes`.'

## Enumeration

`SortByMetric1Enum`

## Fields

| Name |
|  --- |
| `blocks` |
| `bounces` |
| `clicks` |
| `delivered` |
| `opens` |
| `requests` |
| `uniqueClicks` |
| `uniqueOpens` |
| `unsubscribes` |

