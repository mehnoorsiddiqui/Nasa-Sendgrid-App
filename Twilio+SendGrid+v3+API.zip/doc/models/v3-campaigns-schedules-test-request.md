
# V3 Campaigns Schedules Test Request

## Structure

`V3CampaignsSchedulesTestRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `to` | `string` | Required | The email address that should receive the test campaign. |

## Example (as JSON)

```json
{
  "to": "your.email@example.com"
}
```

