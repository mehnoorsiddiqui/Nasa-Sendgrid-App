
# V3 Campaigns Response

## Structure

`V3CampaignsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result` | [`CampaignsResponse[] \| undefined`](../../doc/models/campaigns-response.md) | Optional | - |

## Example (as JSON)

```json
{
  "result": null
}
```

