
# Aggregated by 2 Enum

How to group the statistics. Must be either "day", "week", or "month".

## Enumeration

`AggregatedBy2Enum`

## Fields

| Name |
|  --- |
| `day` |
| `week` |
| `month` |

