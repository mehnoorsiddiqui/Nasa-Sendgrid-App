
# Errors 77

## Structure

`Errors77`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | - |
| `field` | `string \| undefined` | Optional | - |
| `help` | `unknown \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": null,
  "field": null,
  "help": null
}
```

