
# Group by 1 Enum

## Enumeration

`GroupBy1Enum`

## Fields

| Name |
|  --- |
| `abVariation` |
| `abPhase` |

