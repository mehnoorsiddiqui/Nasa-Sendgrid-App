
# V3 Contactdb Recipients Search Response

## Structure

`V3ContactdbRecipientsSearchResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `recipients` | [`ContactDBRecipient[] \| undefined`](../../doc/models/contact-db-recipient.md) | Optional | - |

## Example (as JSON)

```json
{
  "recipients": null
}
```

