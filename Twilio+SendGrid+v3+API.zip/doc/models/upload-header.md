
# Upload Header

## Structure

`UploadHeader`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `header` | `string` | Required | - |
| `value` | `string` | Required | - |

## Example (as JSON)

```json
{
  "header": "header6",
  "value": "value2"
}
```

