
# Error 6

## Structure

`Error6`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | A message explaining why the IP couldn't be removed from warmup. |

## Example (as JSON)

```json
{
  "field": null,
  "message": null
}
```

