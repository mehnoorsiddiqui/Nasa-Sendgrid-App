
# Dkim 12

## Structure

`Dkim12`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `valid` | `boolean \| undefined` | Optional | Indicates if the DNS record is valid. |
| `reason` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "valid": null,
  "reason": null
}
```

