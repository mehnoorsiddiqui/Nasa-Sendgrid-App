
# Metadata 2

## Structure

`Metadata2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prev` | `string \| undefined` | Optional | - |
| `self` | `string \| undefined` | Optional | - |
| `next` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "prev": null,
  "self": null,
  "next": null
}
```

