
# Active Enum

Set the version as the active version associated with the template. Only one version of a template can be active. The first version created for a template will automatically be set to Active.

## Enumeration

`ActiveEnum`

## Fields

| Name |
|  --- |
| `enum0` |
| `enum1` |

