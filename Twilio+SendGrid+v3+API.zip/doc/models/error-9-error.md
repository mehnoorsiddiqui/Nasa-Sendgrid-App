
# Error 9 Error

## Structure

`Error9Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | - |
| `field` | `string` | Required | - |
| `errorId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "message": "message0",
  "field": "field6",
  "error_id": "error_id8"
}
```

