
# Errors 76

## Structure

`Errors76`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string` | Required | - |
| `message` | `string` | Required | A message explaining why your categories could not be retrieved. |

## Example (as JSON)

```json
{
  "field": "field6",
  "message": "message0"
}
```

