
# Errors 19

## Structure

`Errors19`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | - |
| `errorId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "message": "message0",
  "error_id": "error_id8"
}
```

