
# Editor 4 Enum

The editor — `"design"` or `"code"` — used to modify the Single Send's design in the Marketing Campaigns App.

## Enumeration

`Editor4Enum`

## Fields

| Name |
|  --- |
| `code` |
| `design` |

