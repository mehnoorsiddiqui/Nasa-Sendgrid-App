
# Result 10

## Structure

`Result10`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date` | `string \| undefined` | Optional | - |
| `stats` | [`Stat10[] \| undefined`](../../doc/models/stat-10.md) | Optional | - |

## Example (as JSON)

```json
{
  "date": null,
  "stats": null
}
```

