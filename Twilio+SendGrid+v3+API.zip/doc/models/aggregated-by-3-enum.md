
# Aggregated by 3 Enum

How you would like the statistics to by grouped.

## Enumeration

`AggregatedBy3Enum`

## Fields

| Name |
|  --- |
| `day` |
| `week` |
| `month` |

