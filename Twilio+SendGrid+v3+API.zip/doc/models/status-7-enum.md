
# Status 7 Enum

The status of the send you would like to implement. This can be pause or cancel. To delete a pause or cancel status see DELETE /v3/user/scheduled_sends/{batch_id}

## Enumeration

`Status7Enum`

## Fields

| Name |
|  --- |
| `pause` |
| `cancel` |

