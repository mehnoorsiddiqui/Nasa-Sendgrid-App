
# Error 1

## Structure

`Error1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": null
}
```

