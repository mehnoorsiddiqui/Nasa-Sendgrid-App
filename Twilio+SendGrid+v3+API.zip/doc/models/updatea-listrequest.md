
# Updatea Listrequest

## Structure

`UpdateaListrequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Required | The new name for your list. |

## Example (as JSON)

```json
{
  "name": "newlistname"
}
```

