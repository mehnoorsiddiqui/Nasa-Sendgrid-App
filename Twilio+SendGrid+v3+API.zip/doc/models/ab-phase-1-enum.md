
# Ab Phase 1 Enum

This is the A/B phase of the Single Send stat returned. If the `ab_phase` query parameter was not provided, it will return `"all"`.

## Enumeration

`AbPhase1Enum`

## Fields

| Name |
|  --- |
| `send` |
| `test` |
| `all` |

