
# Notifications

## Structure

`Notifications`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email` | `boolean \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "email": null
}
```

