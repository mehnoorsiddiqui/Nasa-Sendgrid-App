
# Country 1 Enum

The country you would like to see statistics for. Currently only supported for US and CA.

## Enumeration

`Country1Enum`

## Fields

| Name |
|  --- |
| `uS` |
| `cA` |

