
# V3 Ips Pools 404 Error 21

## Structure

`V3IpsPools404Error21`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`Errors3[] \| undefined`](../../doc/models/errors-3.md) | Optional | - |

## Example (as JSON)

```json
{
  "errors": null
}
```

