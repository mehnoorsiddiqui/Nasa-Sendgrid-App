
# Metrics 3

## Structure

`Metrics3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `received` | `number` | Required | The number of emails received and parsed by the Parse Webhook. |

## Example (as JSON)

```json
{
  "received": 37.02
}
```

