
# Group by Enum

## Enumeration

`GroupByEnum`

## Fields

| Name |
|  --- |
| `stepId` |

