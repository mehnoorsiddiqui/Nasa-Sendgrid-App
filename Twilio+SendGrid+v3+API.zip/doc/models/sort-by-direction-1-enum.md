
# Sort by Direction 1 Enum

The direction you want to sort.

## Enumeration

`SortByDirection1Enum`

## Fields

| Name |
|  --- |
| `desc` |
| `asc` |

