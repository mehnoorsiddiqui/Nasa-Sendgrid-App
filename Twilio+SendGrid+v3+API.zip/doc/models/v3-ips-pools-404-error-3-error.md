
# V3 Ips Pools 404 Error 3 Error

## Structure

`V3IpsPools404Error3Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`Errors3[] \| undefined`](../../doc/models/errors-3.md) | Optional | - |

## Example (as JSON)

```json
{
  "errors": null
}
```

