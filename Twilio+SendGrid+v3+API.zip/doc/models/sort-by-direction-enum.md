
# Sort by Direction Enum

## Enumeration

`SortByDirectionEnum`

## Fields

| Name |
|  --- |
| `desc` |
| `asc` |

