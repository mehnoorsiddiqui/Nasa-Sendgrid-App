
# V3 Ips Pools Ips 404 Error

## Structure

`V3IpsPoolsIps404Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`Errors1[] \| undefined`](../../doc/models/errors-1.md) | Optional | The error returned. |

## Example (as JSON)

```json
{
  "errors": null
}
```

