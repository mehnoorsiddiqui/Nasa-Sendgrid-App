
# Aggregated by 11 Enum

Dictates how the stats are time-sliced. Currently, `"total"` and `"day"` are supported.

## Enumeration

`AggregatedBy11Enum`

## Fields

| Name |
|  --- |
| `day` |
| `total` |

