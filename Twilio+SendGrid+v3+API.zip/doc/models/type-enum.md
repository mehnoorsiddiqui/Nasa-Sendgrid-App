
# Type Enum

The type of DNS record that was generated.

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `cname` |
| `txt` |
| `mx` |

