
# Reserved Field

## Structure

`ReservedField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | - |
| `type` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "name": null,
  "type": null
}
```

