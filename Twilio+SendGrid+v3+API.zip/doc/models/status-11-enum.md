
# Status 11 Enum

Quick summary of the status of a message

## Enumeration

`Status11Enum`

## Fields

| Name |
|  --- |
| `processed` |
| `notDelivered` |
| `delivered` |

