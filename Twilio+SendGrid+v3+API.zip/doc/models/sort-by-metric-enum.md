
# Sort by Metric Enum

## Enumeration

`SortByMetricEnum`

## Fields

| Name |
|  --- |
| `blocks` |
| `bounces` |
| `clicks` |
| `delivered` |
| `opens` |
| `requests` |
| `uniqueClicks` |
| `uniqueOpens` |
| `unsubscribes` |

