
# Generation 1 Enum

Defines the generation of the template.

## Enumeration

`Generation1Enum`

## Fields

| Name |
|  --- |
| `legacy` |
| `dynamic` |

