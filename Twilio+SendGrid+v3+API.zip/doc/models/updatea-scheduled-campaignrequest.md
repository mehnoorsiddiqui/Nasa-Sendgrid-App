
# Updatea Scheduled Campaignrequest

## Structure

`UpdateaScheduledCampaignrequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sendAt` | `bigint` | Required | - |

## Example (as JSON)

```json
{
  "send_at": 1489451436
}
```

