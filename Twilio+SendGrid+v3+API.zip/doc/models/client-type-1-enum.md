
# Client Type 1 Enum

Specifies the type of client to retrieve stats for. Must be either "phone", "tablet", "webmail", or "desktop".

## Enumeration

`ClientType1Enum`

## Fields

| Name |
|  --- |
| `phone` |
| `tablet` |
| `webmail` |
| `desktop` |

