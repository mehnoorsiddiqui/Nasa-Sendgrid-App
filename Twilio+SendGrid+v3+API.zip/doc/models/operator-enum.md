
# Operator Enum

## Enumeration

`OperatorEnum`

## Fields

| Name |
|  --- |
| `eq` |
| `ne` |
| `lt` |
| `gt` |
| `contains` |

