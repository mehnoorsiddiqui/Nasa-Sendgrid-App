
# Status Enum

The export job's status. Allowed values: `pending`, `ready`, or `failure`.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `pending` |
| `ready` |
| `failure` |

