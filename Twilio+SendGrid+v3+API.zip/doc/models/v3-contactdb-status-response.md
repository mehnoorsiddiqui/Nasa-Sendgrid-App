
# V3 Contactdb Status Response

## Structure

`V3ContactdbStatusResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`Status6[] \| undefined`](../../doc/models/status-6.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": null
}
```

