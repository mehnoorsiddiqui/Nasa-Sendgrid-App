
# Stat 3

## Structure

`Stat3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `metrics` | [`Metrics \| undefined`](../../doc/models/metrics.md) | Optional | - |

## Example (as JSON)

```json
{
  "metrics": null
}
```

