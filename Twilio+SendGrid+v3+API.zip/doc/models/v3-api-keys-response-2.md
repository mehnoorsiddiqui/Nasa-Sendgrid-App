
# V3 Api Keys Response 2

## Structure

`V3ApiKeysResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result` | [`APIKeyNameIDandScopes[] \| undefined`](../../doc/models/api-key-name-i-dand-scopes.md) | Optional | - |

## Example (as JSON)

```json
{
  "result": null
}
```

