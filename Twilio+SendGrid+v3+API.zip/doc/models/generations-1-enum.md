
# Generations 1 Enum

Comma-delimited list specifying which generations of templates to return. Options are `legacy`, `dynamic` or `legacy,dynamic`.

## Enumeration

`Generations1Enum`

## Fields

| Name |
|  --- |
| `legacy` |
| `dynamic` |
| `enumLegacydynamic` |

