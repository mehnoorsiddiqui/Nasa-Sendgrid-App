
# Sort by Direction 4 Enum

The direction to sort the results.

## Enumeration

`SortByDirection4Enum`

## Fields

| Name |
|  --- |
| `desc` |
| `asc` |

