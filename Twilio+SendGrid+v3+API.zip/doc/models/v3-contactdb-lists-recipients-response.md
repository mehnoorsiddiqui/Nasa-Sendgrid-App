
# V3 Contactdb Lists Recipients Response

## Structure

`V3ContactdbListsRecipientsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `recipients` | [`ContactDBRecipient[] \| undefined`](../../doc/models/contact-db-recipient.md) | Optional | - |

## Example (as JSON)

```json
{
  "recipients": null
}
```

