
# Type 3 Enum

The type of alert.

## Enumeration

`Type3Enum`

## Fields

| Name |
|  --- |
| `usageLimit` |
| `statsNotification` |

