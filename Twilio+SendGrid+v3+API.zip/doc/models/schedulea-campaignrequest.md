
# Schedulea Campaignrequest

## Structure

`ScheduleaCampaignrequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sendAt` | `number` | Required | The unix timestamp for the date and time you would like your campaign to be sent out. |

## Example (as JSON)

```json
{
  "send_at": 1489771528
}
```

