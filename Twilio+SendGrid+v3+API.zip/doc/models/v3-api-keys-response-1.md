
# V3 Api Keys Response 1

## Structure

`V3ApiKeysResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `result` | [`APIKeyNameandID[] \| undefined`](../../doc/models/api-key-nameand-id.md) | Optional | - |

## Example (as JSON)

```json
{
  "result": null
}
```

