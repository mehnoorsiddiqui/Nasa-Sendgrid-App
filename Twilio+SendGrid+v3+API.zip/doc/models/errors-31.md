
# Errors 31

## Structure

`Errors31`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | - |
| `errorId` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": "message0",
  "error_id": null
}
```

