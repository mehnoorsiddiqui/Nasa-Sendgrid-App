
# Errors 1

## Structure

`Errors1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | A message explaining why the IP address could not be added to the IP Pool. |

## Example (as JSON)

```json
{
  "field": null,
  "message": null
}
```

