
# V3 Contactdb Reserved Fields Response

## Structure

`V3ContactdbReservedFieldsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservedFields` | [`ReservedField[] \| undefined`](../../doc/models/reserved-field.md) | Optional | - |

## Example (as JSON)

```json
{
  "reserved_fields": null
}
```

