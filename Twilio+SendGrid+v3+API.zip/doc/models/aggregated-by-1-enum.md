
# Aggregated by 1 Enum

## Enumeration

`AggregatedBy1Enum`

## Fields

| Name |
|  --- |
| `day` |
| `total` |

