
# Errors 20

## Structure

`Errors20`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string \| undefined` | Optional | - |
| `message` | `string` | Required | - |
| `errorId` | `string` | Required | - |

## Example (as JSON)

```json
{
  "field": null,
  "message": "message0",
  "error_id": "error_id8"
}
```

