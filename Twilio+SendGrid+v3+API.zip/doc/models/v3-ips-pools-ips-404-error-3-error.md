
# V3 Ips Pools Ips 404 Error 3 Error

## Structure

`V3IpsPoolsIps404Error3Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `string \| undefined` | Optional | An error explaining why the IP address could not be removed from the IP pool. |

## Example (as JSON)

```json
{
  "error": null
}
```

