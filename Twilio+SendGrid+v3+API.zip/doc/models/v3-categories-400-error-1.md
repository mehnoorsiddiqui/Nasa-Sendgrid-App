
# V3 Categories 400 Error 1

## Structure

`V3Categories400Error1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`Errors76[] \| undefined`](../../doc/models/errors-76.md) | Optional | The error returned. |

## Example (as JSON)

```json
{
  "errors": null
}
```

