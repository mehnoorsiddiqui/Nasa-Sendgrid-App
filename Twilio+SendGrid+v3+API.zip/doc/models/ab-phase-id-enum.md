
# Ab Phase Id Enum

## Enumeration

`AbPhaseIdEnum`

## Fields

| Name |
|  --- |
| `test` |
| `send` |

