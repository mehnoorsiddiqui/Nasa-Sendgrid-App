
# File Type Enum

File type for export file. Choose from `json` or `csv`.

## Enumeration

`FileTypeEnum`

## Fields

| Name |
|  --- |
| `csv` |
| `json` |

