
# Client Type Enum

## Enumeration

`ClientTypeEnum`

## Fields

| Name |
|  --- |
| `phone` |
| `tablet` |
| `webmail` |
| `desktop` |

