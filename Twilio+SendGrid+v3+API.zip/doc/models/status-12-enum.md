
# Status 12 Enum

## Enumeration

`Status12Enum`

## Fields

| Name |
|  --- |
| `pending` |

