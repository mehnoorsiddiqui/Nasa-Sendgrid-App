
# And or Enum

## Enumeration

`AndOrEnum`

## Fields

| Name |
|  --- |
| `and` |
| `or` |

