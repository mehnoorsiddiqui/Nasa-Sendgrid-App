
# Segment

## Structure

`Segment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `iD` | `string \| undefined` | Optional | - |
| `name` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "ID": null,
  "Name": null
}
```

