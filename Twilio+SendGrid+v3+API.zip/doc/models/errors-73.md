
# Errors 73

## Structure

`Errors73`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string \| undefined` | Optional | - |
| `message` | `string` | Required | - |

## Example (as JSON)

```json
{
  "field": null,
  "message": "message0"
}
```

