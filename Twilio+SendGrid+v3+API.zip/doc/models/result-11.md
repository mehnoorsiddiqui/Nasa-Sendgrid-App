
# Result 11

## Structure

`Result11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `date` | `string \| undefined` | Optional | - |
| `stats` | [`Stat11[] \| undefined`](../../doc/models/stat-11.md) | Optional | - |

## Example (as JSON)

```json
{
  "date": null,
  "stats": null
}
```

