
# Errors 3

## Structure

`Errors3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | A message explaining why the name of your IP pool could not be updated. |

## Example (as JSON)

```json
{
  "field": null,
  "message": null
}
```

