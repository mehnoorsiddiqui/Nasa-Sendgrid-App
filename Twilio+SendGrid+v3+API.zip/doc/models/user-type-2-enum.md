
# User Type 2 Enum

Indicate the type of user: account owner, teammate admin user, or normal teammate

## Enumeration

`UserType2Enum`

## Fields

| Name |
|  --- |
| `admin` |
| `owner` |
| `teammate` |

