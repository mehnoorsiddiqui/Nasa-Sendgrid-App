
# Stat 11

## Structure

`Stat11`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `domain` | `string \| undefined` | Optional | - |
| `count` | `number \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "domain": null,
  "count": null
}
```

