
# Senda Campaignresponse

## Structure

`SendaCampaignresponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `bigint` | Required | - |
| `status` | `string` | Required | - |

## Example (as JSON)

```json
{
  "id": 112,
  "status": "status8"
}
```

