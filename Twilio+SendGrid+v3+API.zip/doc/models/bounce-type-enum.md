
# Bounce Type Enum

Use to distinguish between types of bounces

## Enumeration

`BounceTypeEnum`

## Fields

| Name |
|  --- |
| `soft` |
| `hard` |

