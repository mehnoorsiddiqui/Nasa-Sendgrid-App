
# Stat 9

## Structure

`Stat9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `string \| undefined` | Optional | The type of segmentation. |
| `name` | `string \| undefined` | Optional | The name of the specific segmentation. |
| `metrics` | [`Metrics8 \| undefined`](../../doc/models/metrics-8.md) | Optional | - |

## Example (as JSON)

```json
{
  "type": null,
  "name": null,
  "metrics": null
}
```

