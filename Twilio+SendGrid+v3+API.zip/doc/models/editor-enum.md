
# Editor Enum

The editor used in the UI.

## Enumeration

`EditorEnum`

## Fields

| Name |
|  --- |
| `code` |
| `design` |

