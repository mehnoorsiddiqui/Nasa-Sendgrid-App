
# Generation Enum

Defines whether the template supports dynamic replacement.

## Enumeration

`GenerationEnum`

## Fields

| Name |
|  --- |
| `legacy` |
| `dynamic` |

