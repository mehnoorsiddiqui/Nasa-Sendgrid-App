
# Error 5

## Structure

`Error5`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | A message explaining why the warmup status could not be retrieved. |

## Example (as JSON)

```json
{
  "field": null,
  "message": null
}
```

