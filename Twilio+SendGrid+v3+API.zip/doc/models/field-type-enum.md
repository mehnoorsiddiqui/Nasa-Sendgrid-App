
# Field Type Enum

## Enumeration

`FieldTypeEnum`

## Fields

| Name |
|  --- |
| `text` |
| `number` |
| `date` |

