
# Stat 1

## Structure

`Stat1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `metrics` | [`Metrics1 \| undefined`](../../doc/models/metrics-1.md) | Optional | - |
| `name` | `string \| undefined` | Optional | The name of the category. |
| `type` | `string` | Required | How you are segmenting your statistics. |

## Example (as JSON)

```json
{
  "metrics": null,
  "name": null,
  "type": "type0"
}
```

