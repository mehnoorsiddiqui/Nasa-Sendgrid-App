
# Custom Fields 1

## Structure

`CustomFields1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `number \| undefined` | Optional | - |
| `name` | `string \| undefined` | Optional | - |
| `value` | `unknown \| undefined` | Optional | - |
| `type` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "value": null,
  "type": null
}
```

