
# Status 10 Enum

## Enumeration

`Status10Enum`

## Fields

| Name |
|  --- |
| `processed` |
| `delivered` |
| `notDelivered` |

