
# Metadata 3

## Structure

`Metadata3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `prev` | `string \| undefined` | Optional | - |
| `self` | `string \| undefined` | Optional | Link to this page. |
| `next` | `string \| undefined` | Optional | Link to next page. |

## Example (as JSON)

```json
{
  "prev": null,
  "self": null,
  "next": null
}
```

