
# Ab Phase Enum

This is the A/B phase of the Single Send stat returned. If the `group_by` parameter doesn't include `ab_phase` in the request, then the value is "all".

## Enumeration

`AbPhaseEnum`

## Fields

| Name |
|  --- |
| `send` |
| `test` |
| `all` |

