
# Classification 1 Enum

The classification you want to filter by. Possible values are: `Content`, `Frequency or Volume Too High`, `Invalid Address`, `Mailbox Unavailable`, `Reputation`, `Technical Failure`, `Unclassified`.

## Enumeration

`Classification1Enum`

## Fields

| Name |
|  --- |
| `content` |
| `enumFrequencyOrVolumeTooHigh` |
| `enumInvalidAddress` |
| `enumMailboxUnavailable` |
| `reputation` |
| `enumTechnicalFailure` |
| `unclassified` |

