
# Outbound Ip Type Enum

Whether or not the outbound IP is dedicated vs shared

## Enumeration

`OutboundIpTypeEnum`

## Fields

| Name |
|  --- |
| `dedicated` |
| `shared` |

