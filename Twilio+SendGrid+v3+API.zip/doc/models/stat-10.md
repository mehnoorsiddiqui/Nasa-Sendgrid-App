
# Stat 10

## Structure

`Stat10`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `classification` | [`ClassificationEnum \| undefined`](../../doc/models/classification-enum.md) | Optional | - |
| `count` | `number \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "classification": null,
  "count": null
}
```

