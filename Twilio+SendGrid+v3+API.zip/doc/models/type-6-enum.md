
# Type 6 Enum

The type of account for this user.

## Enumeration

`Type6Enum`

## Fields

| Name |
|  --- |
| `free` |
| `paid` |

