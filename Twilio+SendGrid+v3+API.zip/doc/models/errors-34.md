
# Errors 34

## Structure

`Errors34`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | - |

## Example (as JSON)

```json
{
  "message": "message0"
}
```

