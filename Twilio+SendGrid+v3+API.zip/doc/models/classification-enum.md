
# Classification Enum

## Enumeration

`ClassificationEnum`

## Fields

| Name |
|  --- |
| `content` |
| `enumFrequencyOrVolumeTooHigh` |
| `enumInvalidAddress` |
| `enumMailboxUnavailable` |
| `reputation` |
| `enumTechnicalFailure` |
| `unclassified` |

