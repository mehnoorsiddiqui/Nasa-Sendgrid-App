
# User Type 1 Enum

Indicate the type of user: owner user, teammate admin user, or normal teammate

## Enumeration

`UserType1Enum`

## Fields

| Name |
|  --- |
| `admin` |
| `owner` |
| `teammate` |

