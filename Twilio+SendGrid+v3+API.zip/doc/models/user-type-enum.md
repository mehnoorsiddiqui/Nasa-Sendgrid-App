
# User Type Enum

A Teammate can be an “admin,” “owner,” or “teammate.” Each role is associated with the scope of the Teammate’s permissions.

## Enumeration

`UserTypeEnum`

## Fields

| Name |
|  --- |
| `admin` |
| `owner` |
| `teammate` |

