
# Status 4 Enum

## Enumeration

`Status4Enum`

## Fields

| Name |
|  --- |
| `scheduled` |

