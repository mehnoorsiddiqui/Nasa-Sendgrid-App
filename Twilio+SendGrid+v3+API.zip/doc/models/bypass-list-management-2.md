
# Bypass List Management 2

## Structure

`BypassListManagement2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enable` | `boolean \| undefined` | Optional | Indicates if this setting is enabled. |

## Example (as JSON)

```json
{
  "enable": null
}
```

