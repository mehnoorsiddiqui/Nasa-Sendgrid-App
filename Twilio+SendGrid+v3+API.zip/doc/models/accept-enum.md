
# Accept Enum

## Enumeration

`AcceptEnum`

## Fields

| Name |
|  --- |
| `enumApplicationjson` |
| `enumTextcsv` |

