
# V3 Ips Pools 404 Error

## Structure

`V3IpsPools404Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`Errors2[] \| undefined`](../../doc/models/errors-2.md) | Optional | - |

## Example (as JSON)

```json
{
  "errors": null
}
```

