
# IP Pools Pool Resp

## Structure

`IPPoolsPoolResp`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | The name of the IP pool. |

## Example (as JSON)

```json
{
  "name": "sunt sint enim"
}
```

