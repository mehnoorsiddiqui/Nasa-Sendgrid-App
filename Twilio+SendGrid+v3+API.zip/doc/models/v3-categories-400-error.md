
# V3 Categories 400 Error

## Structure

`V3Categories400Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`Errors76[] \| undefined`](../../doc/models/errors-76.md) | Optional | The error returned. |

## Example (as JSON)

```json
{
  "errors": null
}
```

