
# SSO Error Response 1 Error

## Structure

`SSOErrorResponse1Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | - |
| `field` | `string \| undefined` | Optional | - |
| `errorId` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": null,
  "field": null,
  "error_id": null
}
```

