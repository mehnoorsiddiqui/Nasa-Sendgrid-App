
# Errors 9

## Structure

`Errors9`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string \| undefined` | Optional | - |
| `field` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "message": null,
  "field": null
}
```

