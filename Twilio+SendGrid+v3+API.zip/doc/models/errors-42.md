
# Errors 42

## Structure

`Errors42`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | `string \| undefined` | Optional | - |
| `message` | `string \| undefined` | Optional | - |
| `errorId` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "field": null,
  "message": null,
  "error_id": null
}
```

