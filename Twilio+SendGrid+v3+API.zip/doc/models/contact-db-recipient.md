
# Contact DB Recipient

## Structure

`ContactDBRecipient`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `recipients` | [`Recipient[] \| undefined`](../../doc/models/recipient.md) | Optional | - |

## Example (as JSON)

```json
{
  "recipients": null
}
```

