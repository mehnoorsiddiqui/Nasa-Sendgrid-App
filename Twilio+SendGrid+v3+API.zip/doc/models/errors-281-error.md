
# Errors 281 Error

## Structure

`Errors281Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`Error9[] \| undefined`](../../doc/models/error-9.md) | Optional | - |

## Example (as JSON)

```json
{
  "errors": null
}
```

