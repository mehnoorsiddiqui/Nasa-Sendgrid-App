
# Status 1 Enum

current status of the Single Send

## Enumeration

`Status1Enum`

## Fields

| Name |
|  --- |
| `draft` |
| `scheduled` |
| `triggered` |

