
# Type 4 Enum

The type of alert.

## Enumeration

`Type4Enum`

## Fields

| Name |
|  --- |
| `usageAlert` |
| `statsNotification` |

