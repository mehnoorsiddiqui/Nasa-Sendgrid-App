
# Aggregated by Enum

## Enumeration

`AggregatedByEnum`

## Fields

| Name |
|  --- |
| `day` |
| `week` |
| `month` |

