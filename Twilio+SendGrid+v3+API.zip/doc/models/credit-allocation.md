
# Credit Allocation

## Structure

`CreditAllocation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "type": null
}
```

