
# Errors 18

## Structure

`Errors18`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Required | A message explaining the reason for the error. |

## Example (as JSON)

```json
{
  "message": "message0"
}
```

